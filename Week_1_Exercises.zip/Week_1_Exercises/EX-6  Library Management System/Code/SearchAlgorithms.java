import java.util.Arrays;
import java.util.Comparator;

public class SearchAlgorithms {

    // Linear search method
    public static Book linearSearch(Book[] books, String targetTitle) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(targetTitle)) {
                return book;
            }
        }
        return null;
    }

    // Binary search method
    public static Book binarySearch(Book[] books, String targetTitle) {
        Arrays.sort(books, Comparator.comparing(Book::getTitle));
        int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(targetTitle);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        Book[] books = {
            new Book("1", "Effective Java", "Joshua Bloch"),
            new Book("2", "Clean Code", "Robert C. Martin"),
            new Book("3", "Design Patterns", "Erich Gamma"),
            new Book("4", "Refactoring", "Martin Fowler"),
            new Book("5", "Head First Java", "Kathy Sierra")
        };

        // Linear Search
        Book linearSearchResult = SearchAlgorithms.linearSearch(books, "Head First Java");
        System.out.println("Linear Search Result: " + (linearSearchResult != null ? linearSearchResult : "Book not found"));

        // Binary Search
        Book binarySearchResult = SearchAlgorithms.binarySearch(books, "Design Patterns");
        System.out.println("Binary Search Result: " + (binarySearchResult != null ? binarySearchResult : "Book not found"));
    }
}
