import java.util.Arrays;
import java.util.Comparator;

public class SearchAlgorithms {

    // Linear search method
    public static int linearSearch(Product[] products, String targetProductName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equalsIgnoreCase(targetProductName)) {
                return i;
            }
        }
        return -1;
    }

    // Binary search method
    public static int binarySearch(Product[] products, String targetProductName) {
        Arrays.sort(products, Comparator.comparing(Product::getProductName));
        int left = 0;
        int right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(targetProductName);
            if (comparison == 0) {
                return mid;
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Mouse", "Electronics"),
            new Product("3", "Keyboard", "Electronics"),
            new Product("4", "Monitor", "Electronics"),
            new Product("5", "Smartphone", "Electronics")
        };

        // Linear Search
        int linearSearchResult = linearSearch(products, "Keyboard");
        System.out.println("Linear Search Result: " + (linearSearchResult != -1 ? products[linearSearchResult] : "Product not found"));

        // Binary Search
        int binarySearchResult = binarySearch(products, "Smartphone");
        System.out.println("Binary Search Result: " + (binarySearchResult != -1 ? products[binarySearchResult] : "Product not found"));
    }
}
