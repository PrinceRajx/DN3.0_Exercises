import java.util.HashMap;

public class Inventory {
    private HashMap<String, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    // Add a product
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    // Update a product
    public void updateProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            products.put(product.getProductId(), product);
        } else {
            System.out.println("Product not found!");
        }
    }

    // Delete a product
    public void deleteProduct(String productId) {
        if (products.containsKey(productId)) {
            products.remove(productId);
        } else {
            System.out.println("Product not found!");
        }
    }

    // Display all products
    public void displayProducts() {
        for (Product product : products.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product product1 = new Product("1", "Laptop", 10, 999.99);
        Product product2 = new Product("2", "Mouse", 50, 19.99);

        // Add products
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Display products
        System.out.println("Initial Inventory:");
        inventory.displayProducts();

        // Update product
        product1.setQuantity(8);
        inventory.updateProduct(product1);

        // Display products after update
        System.out.println("\nAfter update:");
        inventory.displayProducts();

        // Delete product
        inventory.deleteProduct("2");

        // Display products after deletion
        System.out.println("\nAfter deletion:");
        inventory.displayProducts();
    }
}

