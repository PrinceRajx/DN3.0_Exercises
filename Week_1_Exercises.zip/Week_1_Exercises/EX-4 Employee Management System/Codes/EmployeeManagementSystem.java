import java.util.Arrays;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    private int capacity;

    public EmployeeManagementSystem(int capacity) {
        this.capacity = capacity;
        this.employees = new Employee[capacity];
        this.size = 0;
    }

    // Add a new employee
    public void addEmployee(Employee employee) {
        if (size >= capacity) {
            System.out.println("Array is full, cannot add more employees.");
            return;
        }
        employees[size++] = employee;
    }

    // Search for an employee by ID
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse and print all employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by ID
    public void deleteEmployee(String employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            System.out.println("Employee not found.");
            return;
        }

        // Shift elements to the left to fill the gap
        for (int i = index; i < size - 1; i++) {
            employees[i] = employees[i + 1];
        }
        employees[--size] = null;  // Decrease size and nullify the last element
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        Employee emp1 = new Employee("1", "Prince", "Manager", 175000);
        Employee emp2 = new Employee("2", "Ayush", "Developer", 160000);
        Employee emp3 = new Employee("3", "Saurav", "Analyst", 150000);

        ems.addEmployee(emp1);
        ems.addEmployee(emp2);
        ems.addEmployee(emp3);

        System.out.println("Traversing employees:");
        ems.traverseEmployees();

        System.out.println("\nSearching for employee with ID 2:");
        System.out.println(ems.searchEmployee("2"));

        System.out.println("\nDeleting employee with ID 2:");
        ems.deleteEmployee("2");

        System.out.println("\nTraversing employees after deletion:");
        ems.traverseEmployees();
    }
}

