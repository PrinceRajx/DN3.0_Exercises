public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double predictFutureValue(double currentValue, double growthRate, int years) {
        // Base case: if years is 0, return the current value
        if (years == 0) {
            return currentValue;
        }
        // Recursive case: calculate the future value
        return predictFutureValue(currentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double currentValue = 1000.0; // Initial value
        double growthRate = 0.05;     // Annual growth rate (5%)
        int years = 10;               // Number of years to predict

        double futureValue = predictFutureValue(currentValue, growthRate, years);
        System.out.println("Predicted future value after " + years + " years: " + futureValue);
    }
}
